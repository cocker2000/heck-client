package net.kyc.client.impl.event.network;

import net.kyc.client.api.event.Event;

public class GameJoinEvent extends Event {

}
