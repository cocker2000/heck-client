package net.kyc.client.impl.event;

import net.kyc.client.api.event.StageEvent;

/**
 * @author linus
 * @since 1.0
 */
public class TickEvent extends StageEvent {

}
