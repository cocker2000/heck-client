package net.kyc.client.impl.event.entity.passive;

import net.kyc.client.api.event.Cancelable;
import net.kyc.client.api.event.Event;

@Cancelable
public class EntitySteerEvent extends Event {

}
