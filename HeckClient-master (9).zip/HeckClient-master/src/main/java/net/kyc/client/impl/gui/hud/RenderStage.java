package net.kyc.client.impl.gui.hud;

/**
 * Render stages needed to separate image and tex rendering.
 *
 * @author Bebra_tyan(Ferra13671)
 */
public enum RenderStage {
    TEXT,
    IMAGE
}
