package net.kyc.client.api.render;

public enum BoxRender {
    FILL,
    OUTLINE
}
