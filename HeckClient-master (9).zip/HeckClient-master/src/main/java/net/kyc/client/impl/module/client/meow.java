package net.kyc.client.impl.module.client;



public class meow
    {
        public static void  lol (){

        };
}
