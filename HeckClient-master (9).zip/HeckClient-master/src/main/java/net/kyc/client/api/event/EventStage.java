package net.kyc.client.api.event;

public enum EventStage {
    PRE,
    POST
}
