package net.kyc.client.impl.imixin;

public interface IClientPlayerEntity {

    float getLastSpoofedYaw();
    float getLastSpoofedPitch();

}
