package net.kyc.client.impl.manager.combat.hole;

public enum HoleType {
    OBSIDIAN,
    OBSIDIAN_BEDROCK,
    BEDROCK,
    VOID
}
