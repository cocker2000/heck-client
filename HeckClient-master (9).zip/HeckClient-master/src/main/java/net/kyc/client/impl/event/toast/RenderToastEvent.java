package net.kyc.client.impl.event.toast;

import net.kyc.client.api.event.Cancelable;
import net.kyc.client.api.event.Event;

@Cancelable
public class RenderToastEvent extends Event {
}
