package net.kyc.client.impl.event.item;

import net.kyc.client.api.event.Event;

public class FireworkUseEvent extends Event {

}
