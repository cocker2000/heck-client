package net.kyc.client.impl.event.world;

import net.kyc.client.api.event.Cancelable;
import net.kyc.client.api.event.Event;

@Cancelable
public class BlindnessEvent extends Event {

}
