package net.kyc.client.impl.command;



import net.kyc.client.api.command.Command;

/**
 * @author Heckk
 * @since 1.0
 */
public class BaritoneCommand {

}
