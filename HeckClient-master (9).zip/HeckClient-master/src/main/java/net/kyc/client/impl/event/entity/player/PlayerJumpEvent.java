package net.kyc.client.impl.event.entity.player;

import net.kyc.client.api.event.Cancelable;
import net.kyc.client.api.event.StageEvent;

@Cancelable
public class PlayerJumpEvent extends StageEvent {

}
