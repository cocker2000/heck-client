package net.kyc.client.impl.event.item;

import net.kyc.client.api.event.Cancelable;
import net.kyc.client.api.event.Event;

@Cancelable
public class TridentWaterEvent extends Event {

}
