package net.kyc.client.impl.event;

import net.kyc.client.api.event.Cancelable;
import net.kyc.client.api.event.Event;

@Cancelable
public class AttackCooldownEvent extends Event {

}
