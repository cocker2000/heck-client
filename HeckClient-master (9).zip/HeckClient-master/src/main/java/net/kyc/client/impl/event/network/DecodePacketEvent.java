package net.kyc.client.impl.event.network;

import net.kyc.client.api.event.Cancelable;
import net.kyc.client.api.event.Event;

@Cancelable
public class DecodePacketEvent extends Event {

}
