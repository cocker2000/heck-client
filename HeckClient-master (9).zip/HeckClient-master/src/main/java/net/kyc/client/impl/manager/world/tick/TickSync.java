package net.kyc.client.impl.manager.world.tick;

public enum TickSync {
    CURRENT,
    AVERAGE,
    MINIMAL,
    NONE
}
