package net.kyc.client.api.social;

public enum SocialRelation {
    FRIEND
}
