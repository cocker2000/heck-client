package net.kyc.client.impl.event;

import net.kyc.client.api.event.Event;

public class FinishLoadingEvent extends Event {
}
