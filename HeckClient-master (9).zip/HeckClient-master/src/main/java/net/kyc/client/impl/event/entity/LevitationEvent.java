package net.kyc.client.impl.event.entity;

import net.kyc.client.api.event.Cancelable;
import net.kyc.client.api.event.Event;

@Cancelable
public class LevitationEvent extends Event {

}
